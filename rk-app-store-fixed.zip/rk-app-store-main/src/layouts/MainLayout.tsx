import { Outlet } from 'react-router-dom'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { usePageViewTracking } from '@/hooks/usePageViewTracking'
import { isSupabaseConfigured } from '@/lib/supabaseClient'

export default function MainLayout() {
  usePageViewTracking()
  return (
    <div className="flex min-h-screen flex-col">
      {!isSupabaseConfigured && (
        <div className="bg-signal-red px-4 py-2 text-center text-sm text-white">
          Config সমস্যা: VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY এই build-এ নেই। GitHub → Settings → Secrets and
          variables → Actions → <b>Repository secrets</b>-এ দিয়ে Deploy আবার চালাও।
        </div>
      )}
      <Header />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6">
        <Outlet />
      </main>
      <Footer />
    </div>
  )
}
