import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

function isValidHttpUrl(value: string | undefined): value is string {
  if (!value) return false
  try {
    const u = new URL(value)
    return u.protocol === 'https:' || u.protocol === 'http:'
  } catch {
    return false
  }
}

/** false হলে build-এর সময় VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY ঠিকমতো বসেনি। */
export const isSupabaseConfigured = isValidHttpUrl(supabaseUrl) && Boolean(supabaseAnonKey)

if (!isSupabaseConfigured) {
  console.error(
    '[supabase] VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY missing or invalid in this build. ' +
      'GitHub: Settings > Secrets and variables > Actions > Repository secrets-এ দাও, তারপর Deploy আবার চালাও।',
  )
}

// IMPORTANT: supabase-js createClient() THROWS ("supabaseUrl is required") if given an
// empty string. That throw happened at import time, before React mounted, which is
// exactly what produced the blank white screen. Fall back to a harmless placeholder so
// the app still renders (and shows a clear config-error banner) instead of dying.
export const supabase = createClient(
  isSupabaseConfigured ? (supabaseUrl as string) : 'https://placeholder.invalid',
  isSupabaseConfigured ? (supabaseAnonKey as string) : 'placeholder-anon-key',
)
